# Governance

Forecast probabilities are versioned claims, not policy authority. Changes to resolution criteria after a contract freeze require a new contract version. No single maintainer may both change an outcome rule and settle the same contract. External replication and dissenting forecasts are encouraged.
