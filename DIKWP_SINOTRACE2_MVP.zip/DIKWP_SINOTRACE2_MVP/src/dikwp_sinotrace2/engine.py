from __future__ import annotations
import json, math
from dataclasses import dataclass
from pathlib import Path

def sigmoid(x):
    if x>=0:
        z=math.exp(-x); return 1/(1+z)
    z=math.exp(x); return z/(1+z)

def logit(p):
    p=min(max(float(p),1e-9),1-1e-9); return math.log(p/(1-p))

@dataclass(frozen=True)
class Forecast:
    event_id:str; title:str; category:str; probability:float; lower:float; upper:float; event_type:str; state:str; settlement_date:str; peak_window:str; criterion:str; source_ids:list[str]; comparison_region:str|None; features:dict

def feature_score(features,formula):
    z=float(formula['intercept'])
    for k,w in formula['weights'].items():
        v=float(features[k])
        if not 0<=v<=1: raise ValueError(f'{k} outside [0,1]')
        z+=float(w)*v
    return z

def compile_probability(prior,features,formula):
    b=float(formula.get('blend_prior',0.62)); z=b*logit(prior)+(1-b)*feature_score(features,formula)
    return sigmoid(z)

def state(p,event_type,surface):
    if event_type=='NO_EVENT' and p>=.97:return 'S4-强否定走廊'
    if p>=.97 and surface<=.25:return 'S4-结构近必然'
    if p>=.90:return 'S3-高置信走廊'
    if p>=.75:return 'S2-显著优势分支'
    if p>=.45:return 'S1-竞争分支'
    return 'S0-低频或远端分支'

def compile_contracts(path):
    cfg=json.loads(Path(path).read_text(encoding='utf-8')); out=[]
    for e in cfg['events']:
        p=compile_probability(e['analyst_prior'],e['features'],cfg['formula'])
        # Epistemic interval widens for shocks and surface-specific events.
        width=.035+.075*e['features']['surface_specificity']+.045*e['features']['shock_exposure']+.045*e['features']['implementation_friction']
        out.append(Forecast(e['id'],e['title'],e['category'],p,max(0,p-width),min(1,p+width),e['type'],state(p,e['type'],e['features']['surface_specificity']),e['settlement_date'],e['peak_window'],e['resolution_criterion'],e['resolution_sources'],e.get('comparison_region'),e['features']))
    return out

def update_probability(prior,likelihood_ratios):
    z=logit(prior)
    for lr,independence in likelihood_ratios:
        if lr<=0 or not 0<=independence<=1: raise ValueError('invalid evidence')
        z+=independence*math.log(lr)
    return sigmoid(z)
