from __future__ import annotations
import math
def brier_score(p,y):
    if not 0<=p<=1 or y not in (0,1):raise ValueError('invalid')
    return (p-y)**2
def log_score(p,y):
    if not 0<=p<=1 or y not in (0,1):raise ValueError('invalid')
    p=min(max(p,1e-15),1-1e-15); return -math.log(p if y else 1-p)
def calibration_bins(records,bins=10):
    out=[]
    for i in range(bins):
        lo,hi=i/bins,(i+1)/bins; g=[(p,y) for p,y in records if lo<=p<hi or (i==bins-1 and p==1)]
        if g:out.append({'lo':lo,'hi':hi,'count':len(g),'mean_probability':sum(p for p,_ in g)/len(g),'outcome_rate':sum(y for _,y in g)/len(g)})
    return out
