from __future__ import annotations
import random, math
from collections import Counter

def logit(p):
    p=min(max(p,1e-9),1-1e-9); return math.log(p/(1-p))
def sigmoid(z):return 1/(1+math.exp(-z))
LOAD={
'政策治理':(.35,.15,.15,.20,.15),'模型能力':(.10,.55,.15,.10,.10),'智能体产品':(.15,.40,.20,.15,.10),'实体应用':(.20,.25,.25,.20,.10),
'算力能源':(.15,.15,.45,.15,.10),'芯片自主':(.20,.20,.35,.15,.10),'市场扩散':(.20,.25,.15,.25,.15),'风险冲击':(.05,.10,.10,.15,.60),
'国际差分':(.15,.25,.20,.15,.25),'全球治理':(.35,.10,.10,.30,.15),'社会影响':(.20,.15,.10,.25,.30),
}
def simulate(forecasts,trials=20000,seed=7192026):
    rng=random.Random(seed); hits=Counter(); scenarios=Counter(); milestone=[]
    for _ in range(trials):
        # policy implementation, model capability, compute supply, demand/ROI, shock pressure
        latent=[rng.gauss(0,1) for _ in range(5)]
        n=0
        for f in forecasts:
            load=LOAD.get(f.category,(.2,.2,.2,.2,.2)); adj=sum(a*b for a,b in zip(load,latent))*.27
            p=sigmoid(logit(f.probability)+adj)
            if rng.random()<p:hits[f.event_id]+=1;n+=1
        milestone.append(n)
        if latent[4]>.95:scenarios['安全事故与治理收紧']+=1
        elif latent[2]<-.85:scenarios['外部限制与算力瓶颈']+=1
        elif latent[1]>.70 and latent[0]>.25:scenarios['开源效率与模型跃迁']+=1
        elif latent[3]<-.85:scenarios['需求回报失速与整合']+=1
        else:scenarios['应用扩散与受控智能体主走廊']+=1
    milestone.sort()
    q=lambda z: milestone[int((trials-1)*z)]
    return {'trials':trials,'seed':seed,'scenario_shares':{k:v/trials for k,v in scenarios.items()},'event_frequencies':{k:v/trials for k,v in hits.items()},'milestone_count':{'p10':q(.1),'median':q(.5),'p90':q(.9)}}
