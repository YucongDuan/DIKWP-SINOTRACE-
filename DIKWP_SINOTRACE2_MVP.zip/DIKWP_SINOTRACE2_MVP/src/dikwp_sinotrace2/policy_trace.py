from __future__ import annotations
import json
from pathlib import Path

def compile_policy_trace(path):
    x=json.loads(Path(path).read_text(encoding='utf-8'))
    rows=[]
    for c in x['commitments']:
        rows.append({'commitment_id':c['id'],'surface_phrase':c['surface_phrase'],'relation_kernel':c['non_definitional_reading'],'observable_action_count':len(c['observable_actions']),'observable_actions':c['observable_actions'],'intent_fields':c['intent_fields']})
    return {'snapshot_date':x['snapshot_date'],'commitment_count':len(rows),'rows':rows}
