"""DIKWP-SINOTRACE²: China AI intent-trace and 12-month differential forecast system."""
__version__="0.1.0"
