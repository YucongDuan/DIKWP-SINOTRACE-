from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json
TYPES=("D","I","K","W","P")
DESC={
"D":"可追溯事实、政策、发布、部署和统计",
"I":"差异、关系、趋势、时序和语境",
"K":"可检验因果模型、竞争解释和反事实",
"W":"长期后果、权利、风险、文化和分配",
"P":"目的、权限、资源方向、拒绝和行动边界",
}
@dataclass(frozen=True)
class Transform:
    source:str; target:str; operator_id:str; description:str

def all_transforms():
    return [Transform(s,t,f"T-{s}{t}",f"在观察者、时间、尺度和意图场索引下，以{DESC[s]}生成、质疑或修订{DESC[t]}。") for s in TYPES for t in TYPES]

def mixed_type(v):
    x={k:max(0.0,float(v.get(k,0))) for k in TYPES}; total=sum(x.values())
    return {k:(x[k]/total if total else 0.2) for k in TYPES}

def relation_fingerprint(bundle,erase_concepts=True):
    traces=[]
    for item in bundle.get('traces',[]):
        traces.append({'id':item.get('id'),'observer':item.get('observer'),'source':item.get('source'),'target':item.get('target'),'relation':item.get('relation'),'dikwp':mixed_type(item.get('dikwp',{})),'concept':None if erase_concepts else item.get('concept')})
    if erase_concepts:
        for t in traces:t.pop('concept',None)
    payload=json.dumps(sorted(traces,key=lambda x:str(x.get('id'))),ensure_ascii=False,sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()

def concept_erasure_invariant(bundle):
    stripped={'traces':[]}
    for x in bundle.get('traces',[]):
        y=dict(x); y.pop('concept',None); stripped['traces'].append(y)
    return relation_fingerprint(bundle,True)==relation_fingerprint(stripped,True)
