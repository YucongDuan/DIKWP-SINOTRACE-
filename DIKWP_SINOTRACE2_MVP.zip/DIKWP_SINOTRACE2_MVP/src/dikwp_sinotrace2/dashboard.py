from __future__ import annotations
import html,json
from pathlib import Path

def build_dashboard(forecasts,sim,trace,diff,out):
    top=sorted(forecasts,key=lambda x:-x.probability)[:16]
    cards=''.join(f"<article><div class=p>{f.probability*100:.1f}%</div><h3>{html.escape(f.title)}</h3><p>{html.escape(f.category)} · {html.escape(f.state)}</p></article>" for f in top)
    rows=''.join(f"<tr><td>{f.event_id}</td><td>{html.escape(f.title)}</td><td>{html.escape(f.category)}</td><td>{f.probability*100:.1f}%<br><small>{f.lower*100:.1f}–{f.upper*100:.1f}</small></td><td>{html.escape(f.settlement_date)}</td><td>{html.escape(f.criterion)}</td></tr>" for f in sorted(forecasts,key=lambda x:(x.category,-x.probability)))
    scen=''.join(f"<li><b>{html.escape(k)}</b>：{v*100:.1f}%</li>" for k,v in sorted(sim['scenario_shares'].items(),key=lambda kv:-kv[1]))
    traces=''.join(f"<tr><td>{r['commitment_id']}</td><td>{html.escape(r['surface_phrase'])}</td><td>{html.escape(r['relation_kernel'])}</td><td>{'<br>'.join(map(html.escape,r['observable_actions']))}</td></tr>" for r in trace['rows'])
    axes=diff['axes']; head=''.join(f'<th>{html.escape(a)}</th>' for a in axes)
    drows=''.join('<tr><th>'+html.escape(name)+'</th>'+''.join(f'<td>{vals[a]:.2f}</td>' for a in axes)+'</tr>' for name,vals in diff['regions'].items())
    doc=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DIKWP-SINOTRACE²</title><style>
body{{font-family:system-ui,-apple-system,"Noto Sans CJK SC",sans-serif;background:#f4f6f9;color:#182131;margin:0}}header{{background:#17233a;color:white;padding:42px 5vw}}main{{max-width:1500px;margin:auto;padding:24px}}section,article{{background:white;border:1px solid #dce3eb;border-radius:12px;padding:17px;box-shadow:0 2px 8px #0000000c}}section{{margin-bottom:18px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px}}.p{{font-size:32px;font-weight:800}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{border-bottom:1px solid #e5e9ef;padding:9px;text-align:left;vertical-align:top}}small{{color:#667085}}code{{background:#eef1f5;padding:2px 5px;border-radius:5px}}@media(max-width:800px){{table{{font-size:11px}}}}</style></head><body>
<header><h1>DIKWP-SINOTRACE²</h1><p>中国人工智能意图兑现、结构转轨、风险触发与国际差分预测系统</p><p>冻结快照：2026-07-19 · 结算上限：2027-07-19</p></header><main>
<section><h2>高置信预测</h2><div class=grid>{cards}</div></section>
<section><h2>讲话字面到可结算行动</h2><table><thead><tr><th>ID</th><th>表面表述</th><th>关系核</th><th>可观测兑现</th></tr></thead><tbody>{traces}</tbody></table></section>
<section><h2>国际差分向量（演示参数，不是总排名）</h2><table><thead><tr><th>区域</th>{head}</tr></thead><tbody>{drows}</tbody></table><small>{html.escape(diff['note'])}</small></section>
<section><h2>20,000次结构压力测试</h2><ul>{scen}</ul><p>同时兑现合同数：P10={sim['milestone_count']['p10']}，中位数={sim['milestone_count']['median']}，P90={sim['milestone_count']['p90']}。</p></section>
<section><h2>全部预测合同</h2><table><thead><tr><th>ID</th><th>事件</th><th>类别</th><th>概率/区间</th><th>结算日</th><th>结算条件</th></tr></thead><tbody>{rows}</tbody></table></section>
<section><h2>解释边界</h2><p>“机器思考”“AGI”“普惠”等名称不是本系统的固定定义。系统追踪的是政策、能力、部署、资源、权利和国际竞争之间可重复观察的关系。概率是2026-07-19种子快照，需要按月更新并到期结算。</p></section>
</main></body></html>'''
    Path(out).write_text(doc,encoding='utf-8')
