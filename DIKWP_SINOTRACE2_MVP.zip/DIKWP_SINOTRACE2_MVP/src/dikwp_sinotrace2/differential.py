from __future__ import annotations
import json
from pathlib import Path

def compile_differential(path):
    x=json.loads(Path(path).read_text(encoding='utf-8')); regs=x['regions']; axes=x['axes']
    pairwise={}
    for a in regs:
        for b in regs:
            if a>=b: continue
            pairwise[f'{a}__{b}']={axis:round(regs[a][axis]-regs[b][axis],3) for axis in axes}
    return {'snapshot_date':x['snapshot_date'],'axes':axes,'regions':regs,'pairwise_differences':pairwise,'note':x['note']}
