from __future__ import annotations
import argparse,csv,hashlib,json
from dataclasses import asdict
from datetime import date
from pathlib import Path
from .engine import compile_contracts
from .mesh import all_transforms,concept_erasure_invariant
from .policy_trace import compile_policy_trace
from .differential import compile_differential
from .simulation import simulate
from .dashboard import build_dashboard

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for c in iter(lambda:f.read(1<<20),b''):h.update(c)
    return h.hexdigest()

def main(argv=None):
    ap=argparse.ArgumentParser();ap.add_argument('--config',default='config/forecast_contracts.json');ap.add_argument('--policy',default='config/policy_commitments.json');ap.add_argument('--comparison',default='config/international_comparison.json');ap.add_argument('--out',default='outputs');ap.add_argument('--trials',type=int,default=20000);ap.add_argument('--seed',type=int,default=7192026);args=ap.parse_args(argv)
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    fc=compile_contracts(args.config); trace=compile_policy_trace(args.policy); diff=compile_differential(args.comparison); sim=simulate(fc,args.trials,args.seed)
    (out/'forecast_contracts_compiled.json').write_text(json.dumps([asdict(x) for x in fc],ensure_ascii=False,indent=2),encoding='utf-8')
    with (out/'forecast_contracts.csv').open('w',newline='',encoding='utf-8-sig') as f:
        wr=csv.writer(f);wr.writerow(['id','title','category','probability','lower','upper','state','settlement_date','peak_window','comparison_region','criterion'])
        for x in fc:wr.writerow([x.event_id,x.title,x.category,f'{x.probability:.6f}',f'{x.lower:.6f}',f'{x.upper:.6f}',x.state,x.settlement_date,x.peak_window,x.comparison_region or '',x.criterion])
    (out/'policy_speech_trace.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'international_differential.json').write_text(json.dumps(diff,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'scenario_summary.json').write_text(json.dumps(sim,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'dikwp_25_transforms.json').write_text(json.dumps([asdict(x) for x in all_transforms()],ensure_ascii=False,indent=2),encoding='utf-8')
    bundle=json.loads(Path('examples/speech_trace_bundle.json').read_text(encoding='utf-8'))
    (out/'definition_free_audit.json').write_text(json.dumps({'concept_erasure_invariant':concept_erasure_invariant(bundle)},ensure_ascii=False,indent=2),encoding='utf-8')
    build_dashboard(fc,sim,trace,diff,out/'dashboard.html')
    proof={'system':'DIKWP-SINOTRACE²','run_at':date.today().isoformat(),'snapshot_date':'2026-07-19','horizon_end':'2027-07-19','trials':args.trials,'seed':args.seed,'forecast_count':len(fc),'transform_count':len(all_transforms()),'files':{}}
    for p in sorted(out.iterdir()):
        if p.is_file() and p.name!='RUN_PROOF.json':proof['files'][p.name]=sha256(p)
    (out/'RUN_PROOF.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'forecast_count':len(fc),'dashboard':str(out/'dashboard.html'),'trials':args.trials},ensure_ascii=False))
if __name__=='__main__':main()
