# Contributing

Contributions should add evidence, counter-evidence, alternative intent fields, independent forecast models, or settlement records. Do not submit post-hoc changes that make a forecast easier to pass. Every material change must include tests and a rationale.
