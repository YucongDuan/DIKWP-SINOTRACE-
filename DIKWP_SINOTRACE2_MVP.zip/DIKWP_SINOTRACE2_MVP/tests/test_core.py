import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'src'))
from dikwp_sinotrace2.engine import compile_contracts,update_probability
from dikwp_sinotrace2.mesh import all_transforms,concept_erasure_invariant,mixed_type
from dikwp_sinotrace2.policy_trace import compile_policy_trace
from dikwp_sinotrace2.differential import compile_differential
from dikwp_sinotrace2.simulation import simulate
from dikwp_sinotrace2.settlement import brier_score,log_score

def test_25_transforms(): assert len(all_transforms())==25 and len({x.operator_id for x in all_transforms()})==25
def test_contract_count(): assert len(compile_contracts('config/forecast_contracts.json'))>=50
def test_probabilities(): assert all(0<x.probability<1 for x in compile_contracts('config/forecast_contracts.json'))
def test_intervals(): assert all(0<=x.lower<=x.probability<=x.upper<=1 for x in compile_contracts('config/forecast_contracts.json'))
def test_erasure(): assert concept_erasure_invariant(json.loads(Path('examples/speech_trace_bundle.json').read_text()))
def test_mixed(): assert abs(sum(mixed_type({'D':2,'P':3}).values())-1)<1e-9
def test_policy_trace(): assert compile_policy_trace('config/policy_commitments.json')['commitment_count']>=6
def test_differential(): assert len(compile_differential('config/international_comparison.json')['regions'])==3
def test_simulation(): assert simulate(compile_contracts('config/forecast_contracts.json'),100,7)['trials']==100
def test_update(): assert update_probability(.5,[(2,.8)])>.5
def test_brier(): assert brier_score(.8,1)<brier_score(.2,1)
def test_log(): assert log_score(.8,1)<log_score(.2,1)
def test_high_confidence():
    f={x.event_id:x for x in compile_contracts('config/forecast_contracts.json')}; assert f['CN-P07'].probability>.95 and f['INT-D01'].probability>.9
def test_no_ontology_score():
    # Comparison vectors are separate axes; no aggregate 'China AI level' is generated.
    x=json.loads(Path('config/international_comparison.json').read_text()); assert 'overall_score' not in x
