# Security Policy

This repository is an offline research prototype. It must not autonomously deploy policy, access production systems, or make consequential decisions. Report vulnerabilities through a private maintainer channel before public disclosure.
